<template>
    <div>
        <h1>购物车</h1>
        {{ $route.query.skill }}
        {{ $route.query.title }}
    </div>
</template>

<script>
export default {
 data() {
     return {};
 },
 methods: {},
};
</script>

<style lang="scss" scoped>

</style>