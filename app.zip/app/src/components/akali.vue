<template>
  <div>
    <h2>akali页面</h2>

    <p>爱好：敲代码</p>
    <p>兴趣：旅游</p>
    <p>名称:儿子</p>
    <a href="#">跳转到劫</a>
    <button @click="dian">点击跳转到阿卡丽</button>
    <button>点击跳转到劫</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      time: null, //存放定时器
    };
  },
  beforeRouteEnter(to, from, next) {
    // ...
    console.log(to, from, next);
    next();
  },
  beforeRouteLeave(to, from, next) {
    // ...
    console.log(to, from, next);
    if (this.time) {
      clearInterval(this.time)
    }
    next();

  },
  beforeRouteUpdate(to, from, next) {
    console.log(to, from, next);
    next();
  },
  deactivated() {
    console.log("deactivated");
  },
  activated() {
    console.log("activated");
  },
  methods: {
    dian() {
      this.time.setInterval(() => {
     console.log(Math.floor(Math.random()));

      }, 2000);
    },
  },
};
</script>

<style lang="scss" scoped></style>
